package com.example.javaee_02_romanenko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaEe02RomanenkoApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaEe02RomanenkoApplication.class, args);
    }

}
