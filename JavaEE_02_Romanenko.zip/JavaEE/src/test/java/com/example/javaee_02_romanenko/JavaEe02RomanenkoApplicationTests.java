package com.example.javaee_02_romanenko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaEe02RomanenkoApplicationTests {

    @Test
    void contextLoads() {
    }

}
